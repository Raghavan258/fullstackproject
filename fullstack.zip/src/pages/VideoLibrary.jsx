import React, { useState } from 'react';
import './Pages.css';

const VIDEOS = [
  { id: 1, title: 'Understanding the Preamble of India', educator: 'Priya Menon', duration: '18 min', category: 'Preamble', thumb: '🎬', url: '#' },
  { id: 2, title: 'Fundamental Rights — Articles 12 to 35', educator: 'Dr. Rao', duration: '32 min', category: 'Fundamental Rights', thumb: '📹', url: '#' },
  { id: 3, title: 'Right to Equality Deep Dive', educator: 'Adv. Sharma', duration: '22 min', category: 'Fundamental Rights', thumb: '🎥', url: '#' },
  { id: 4, title: 'Directive Principles and Their Importance', educator: 'Priya Menon', duration: '25 min', category: 'DPSP', thumb: '🎬', url: '#' },
  { id: 5, title: 'Constitutional Amendments Timeline', educator: 'Dr. Rao', duration: '40 min', category: 'Amendments', thumb: '📹', url: '#' },
  { id: 6, title: 'Landmark Cases — Kesavananda Bharati', educator: 'Adv. Sharma', duration: '35 min', category: 'Case Studies', thumb: '🎥', url: '#' },
];

const CATEGORIES = ['All', ...new Set(VIDEOS.map(v => v.category))];

export default function VideoLibrary() {
  const [cat, setCat] = useState('All');
  const filtered = cat === 'All' ? VIDEOS : VIDEOS.filter(v => v.category === cat);

  return (
    <div className="page-content container">
      <div className="page-hero">
        <div className="section-tag">🎥 Video Library</div>
        <h1 className="page-title heading-display">Video <span className="saffron-text">Lectures</span></h1>
        <p className="page-sub">Educator-curated video modules on the Indian Constitution.</p>
      </div>

      <div className="cat-filter">
        {CATEGORIES.map(c => (
          <button key={c} className={`cat-btn ${cat === c ? 'active' : ''}`} onClick={() => setCat(c)}>{c}</button>
        ))}
      </div>

      <div className="grid-3">
        {filtered.map(v => (
          <div key={v.id} className="video-card glass-card">
            <div className="video-thumb">{v.thumb}</div>
            <div className="video-info">
              <div className="video-category badge badge-navy mb-8">{v.category}</div>
              <h3 className="video-title">{v.title}</h3>
              <div className="video-meta">
                <span>👤 {v.educator}</span>
                <span>⏱ {v.duration}</span>
              </div>
              <a href={v.url} className="btn btn-primary" style={{marginTop:'12px',fontSize:'0.82rem',padding:'9px 18px'}}>▶ Watch Now</a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
