import React, { useState } from 'react';
import './Pages.css';

const QUESTIONS = [
  { q: 'What does the word "Sovereign" in the Preamble mean?', options: ['India is supreme', 'India is democratic', 'India is not dependent on any outside power', 'India has a single ruler'], ans: 2 },
  { q: 'Which Article guarantees Right to Equality?', options: ['Article 12', 'Article 14', 'Article 19', 'Article 21'], ans: 1 },
  { q: 'The Right to Education was added by which Amendment?', options: ['42nd', '86th', '44th', '91st'], ans: 1 },
  { q: 'Article 21 deals with:', options: ['Right to Vote', 'Right to Property', 'Right to Life and Personal Liberty', 'Right to Education'], ans: 2 },
  { q: 'Which case established the Basic Structure Doctrine?', options: ['Maneka Gandhi vs Union of India', 'Kesavananda Bharati vs State of Kerala', 'Golaknath vs State of Punjab', 'Minerva Mills vs Union of India'], ans: 1 },
];

export default function Quizzes() {
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const pick = (qi, oi) => { if (!submitted) setAnswers(p => ({ ...p, [qi]: oi })); };
  const score = Object.entries(answers).filter(([qi, oi]) => QUESTIONS[parseInt(qi)].ans === oi).length;

  return (
    <div className="page-content container">
      <div className="page-hero">
        <div className="section-tag">🧠 Quizzes</div>
        <h1 className="page-title heading-display">Test Your <span className="saffron-text">Knowledge</span></h1>
        <p className="page-sub">5 questions on the Indian Constitution. Select an answer for each and submit.</p>
      </div>

      {submitted && (
        <div className={`quiz-score-banner ${score >= 4 ? 'great' : score >= 2 ? 'good' : 'try'}`}>
          <span className="quiz-score-icon">{score >= 4 ? '🏆' : score >= 2 ? '👏' : '📚'}</span>
          <div>
            <div className="quiz-score-text">You scored {score} / {QUESTIONS.length}</div>
            <div className="quiz-score-sub">{score >= 4 ? 'Excellent! You know your Constitution.' : score >= 2 ? 'Good effort! Review the incorrect answers.' : 'Keep studying! You can do better.'}</div>
          </div>
          <button className="btn btn-primary" style={{marginLeft:'auto'}} onClick={() => { setAnswers({}); setSubmitted(false); }}>Retake Quiz</button>
        </div>
      )}

      <div className="quiz-questions">
        {QUESTIONS.map((q, qi) => (
          <div key={qi} className="quiz-card glass-card">
            <div className="quiz-num">Question {qi + 1}</div>
            <p className="quiz-q">{q.q}</p>
            <div className="quiz-options">
              {q.options.map((opt, oi) => {
                let cls = 'quiz-option';
                if (submitted) {
                  if (oi === q.ans) cls += ' correct';
                  else if (answers[qi] === oi) cls += ' wrong';
                } else if (answers[qi] === oi) cls += ' selected';
                return (
                  <button key={oi} className={cls} onClick={() => pick(qi, oi)}>
                    <span className="opt-letter">{String.fromCharCode(65 + oi)}</span>
                    {opt}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {!submitted && (
        <button
          id="quiz-submit-btn"
          className="btn btn-primary"
          style={{ fontSize: '1rem', padding: '14px 40px', marginTop: '8px' }}
          onClick={() => setSubmitted(true)}
          disabled={Object.keys(answers).length < QUESTIONS.length}
        >
          Submit Quiz →
        </button>
      )}
    </div>
  );
}
