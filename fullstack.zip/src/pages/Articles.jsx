import React, { useState } from 'react';
import './Pages.css';

const ARTICLES = [
  { id: 1, part: 'Part I', title: 'Article 1 — Name and Territory of the Union', summary: 'India, that is Bharat, shall be a Union of States.', tags: ['Union', 'Territory'] },
  { id: 2, part: 'Part III', title: 'Article 14 — Right to Equality', summary: 'The State shall not deny to any person equality before the law or the equal protection of the laws within the territory of India.', tags: ['Fundamental Rights', 'Equality'] },
  { id: 3, part: 'Part III', title: 'Article 19 — Freedom of Speech', summary: 'All citizens shall have the right to freedom of speech and expression, to assemble peaceably, to form associations, to move freely, and to practise any profession.', tags: ['Fundamental Rights', 'Freedom'] },
  { id: 4, part: 'Part III', title: 'Article 21 — Right to Life', summary: 'No person shall be deprived of his life or personal liberty except according to procedure established by law.', tags: ['Fundamental Rights', 'Life', 'Liberty'] },
  { id: 5, part: 'Part III', title: 'Article 21A — Right to Education', summary: 'The State shall provide free and compulsory education to all children of the age of six to fourteen years.', tags: ['Fundamental Rights', 'Education'] },
  { id: 6, part: 'Part III', title: 'Article 32 — Right to Constitutional Remedies', summary: 'The right to move the Supreme Court by appropriate proceedings for the enforcement of the rights conferred by this Part is guaranteed.', tags: ['Fundamental Rights', 'Remedies'] },
  { id: 7, part: 'Part IV-A', title: 'Article 51A — Fundamental Duties', summary: 'It shall be the duty of every citizen of India to abide by the Constitution and respect its ideals and institutions, the National Flag and the National Anthem.', tags: ['Duties', 'Citizens'] },
  { id: 8, part: 'Part V', title: 'Article 79 — Constitution of Parliament', summary: 'There shall be a Parliament for the Union which shall consist of the President and two Houses to be known respectively as the Council of States and the House of the People.', tags: ['Parliament', 'Union'] },
];

const ALL_PARTS = [...new Set(ARTICLES.map(a => a.part))];

export default function Articles() {
  const [search, setSearch] = useState('');
  const [filterPart, setFilterPart] = useState('');
  const [expanded, setExpanded] = useState(null);

  const filtered = ARTICLES.filter(a => {
    const q = search.toLowerCase();
    const matchSearch = !q || a.title.toLowerCase().includes(q) || a.summary.toLowerCase().includes(q);
    const matchPart = !filterPart || a.part === filterPart;
    return matchSearch && matchPart;
  });

  return (
    <div className="page-content container">
      <div className="page-hero">
        <div className="section-tag">📜 Constitutional Articles</div>
        <h1 className="page-title heading-display">Browse <span className="saffron-text">Articles</span></h1>
        <p className="page-sub">Explore the key articles of the Indian Constitution with summaries and expert annotations.</p>
      </div>

      {/* Filters */}
      <div className="filter-bar">
        <input
          className="form-input search-input"
          placeholder="🔍 Search articles..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <select className="form-select" style={{width:'180px'}} value={filterPart} onChange={e => setFilterPart(e.target.value)}>
          <option value="">All Parts</option>
          {ALL_PARTS.map(p => <option key={p} value={p}>{p}</option>)}
        </select>
      </div>

      <div className="articles-list">
        {filtered.map(a => (
          <div
            key={a.id}
            className={`article-card glass-card ${expanded === a.id ? 'expanded' : ''}`}
            onClick={() => setExpanded(expanded === a.id ? null : a.id)}
          >
            <div className="article-card-header">
              <div>
                <span className="badge badge-navy" style={{marginBottom:'8px',display:'inline-flex'}}>{a.part}</span>
                <h3 className="article-title">{a.title}</h3>
              </div>
              <span className="article-chevron">{expanded === a.id ? '▲' : '▼'}</span>
            </div>
            {expanded === a.id && (
              <div className="article-body">
                <p className="article-summary">{a.summary}</p>
                <div className="article-tags">
                  {a.tags.map(t => <span key={t} className="badge badge-saffron">{t}</span>)}
                </div>
              </div>
            )}
          </div>
        ))}
        {filtered.length === 0 && (
          <div style={{textAlign:'center',padding:'60px',color:'var(--text-muted)'}}>
            No articles match your search.
          </div>
        )}
      </div>
    </div>
  );
}
