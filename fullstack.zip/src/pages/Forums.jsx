import React, { useState } from 'react';
import './Pages.css';

const THREADS = [
  { id: 1, topic: 'Preamble', title: 'Does "Socialist" in the Preamble restrict economic freedom?', author: 'Arjun S.', replies: 14, likes: 32, time: '2h ago' },
  { id: 2, topic: 'Rights', title: 'Is Freedom of Speech absolute under Article 19?', author: 'Meera K.', replies: 28, likes: 67, time: '5h ago' },
  { id: 3, topic: 'Duties', title: 'How should Fundamental Duties be enforced?', author: 'Rahul V.', replies: 9, likes: 18, time: '1d ago' },
  { id: 4, topic: 'Amendments', title: '42nd vs 44th Amendment — Key Differences', author: 'Priya M.', replies: 22, likes: 45, time: '2d ago' },
];

const TOPICS = ['All', 'Preamble', 'Rights', 'Duties', 'Amendments'];

export default function Forums() {
  const [topic, setTopic] = useState('All');
  const [newPost, setNewPost] = useState('');
  const filtered = topic === 'All' ? THREADS : THREADS.filter(t => t.topic === topic);

  return (
    <div className="page-content container">
      <div className="page-hero">
        <div className="section-tag">💬 Community Forums</div>
        <h1 className="page-title heading-display">Discussion <span className="saffron-text">Forums</span></h1>
        <p className="page-sub">Discuss constitutional topics with fellow citizens, educators, and legal experts.</p>
      </div>

      <div className="cat-filter mb-24">
        {TOPICS.map(t => (
          <button key={t} className={`cat-btn ${topic === t ? 'active' : ''}`} onClick={() => setTopic(t)}>{t}</button>
        ))}
      </div>

      {/* New Post */}
      <div className="glass-card dash-section-card mb-24">
        <h3 style={{marginBottom:'12px',fontSize:'0.95rem',fontWeight:700}}>✍️ Start a New Discussion</h3>
        <textarea
          className="form-input"
          rows={3}
          placeholder="Share your thoughts on the Constitution..."
          value={newPost}
          onChange={e => setNewPost(e.target.value)}
          style={{resize:'vertical'}}
        />
        <button className="btn btn-primary mt-8" style={{fontSize:'0.82rem',padding:'9px 20px'}} onClick={() => setNewPost('')}>
          Post Discussion
        </button>
      </div>

      <div className="forum-threads">
        {filtered.map(t => (
          <div key={t.id} className="thread-card glass-card">
            <span className="badge badge-navy" style={{marginBottom:'10px',display:'inline-flex'}}>{t.topic}</span>
            <h3 className="thread-title">{t.title}</h3>
            <div className="thread-meta">
              <span>👤 {t.author}</span>
              <span>💬 {t.replies} replies</span>
              <span>❤️ {t.likes} likes</span>
              <span>{t.time}</span>
            </div>
            <button className="btn btn-ghost" style={{marginTop:'12px',fontSize:'0.8rem',padding:'7px 16px'}}>Join Discussion →</button>
          </div>
        ))}
      </div>
    </div>
  );
}
