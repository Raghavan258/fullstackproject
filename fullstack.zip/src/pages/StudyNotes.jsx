import React, { useState } from 'react';
import './Pages.css';

const NOTES = [
  { id: 1, title: 'Preamble — Word by Word Analysis', author: 'Priya Menon', date: '2026-04-01', preview: 'The preamble uses specific constitutional terms. "Sovereign" means India is not under any external authority. "Socialist" was added by the 42nd Amendment...', tag: 'Preamble' },
  { id: 2, title: 'Fundamental Rights Summary Sheet', author: 'Dr. Rao', date: '2026-03-28', preview: 'Six categories: Right to Equality (14-18), Right to Freedom (19-22), Right Against Exploitation (23-24), Right to Religion (25-28), Cultural/Education Rights (29-30), Constitutional Remedies (32)...', tag: 'Rights' },
  { id: 3, title: 'Constitution vs. Ordinary Law', author: 'Adv. Sharma', date: '2026-03-20', preview: 'The Constitution is supreme — all laws must be consistent with it. Any law inconsistent with fundamental rights is void under Article 13...', tag: 'Constitutional Law' },
  { id: 4, title: 'Directive Principles vs Fundamental Rights', author: 'Priya Menon', date: '2026-03-15', preview: 'DPSPs are non-justiciable guidelines for the state. Though courts cannot enforce them, they are fundamental to governance. The Minerva Mills case (1980) balanced both...', tag: 'DPSP' },
];

export default function StudyNotes() {
  const [search, setSearch] = useState('');
  const filtered = NOTES.filter(n => n.title.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="page-content container">
      <div className="page-hero">
        <div className="section-tag">📓 Study Notes</div>
        <h1 className="page-title heading-display">Study <span className="saffron-text">Notes</span></h1>
        <p className="page-sub">Educator-authored notes on key constitutional topics.</p>
      </div>

      <input
        className="form-input search-input mb-24"
        placeholder="🔍 Search notes..."
        value={search}
        onChange={e => setSearch(e.target.value)}
      />

      <div className="notes-list">
        {filtered.map(n => (
          <div key={n.id} className="note-card glass-card">
            <div className="note-tag badge badge-saffron">{n.tag}</div>
            <h3 className="note-title">{n.title}</h3>
            <p className="note-preview">{n.preview}</p>
            <div className="note-footer">
              <span>✍️ {n.author}</span>
              <span>{n.date}</span>
              <button className="btn btn-outline" style={{fontSize:'0.78rem',padding:'6px 14px'}}>Read Full Note</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
