import React, { useState, useRef, useEffect } from 'react';
import './OTPModal.css';

const MOCK_OTP = '123456'; // Replace with JDC backend call

export default function OTPModal({ email, onVerified, onClose }) {
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [status, setStatus] = useState('idle'); // idle | success | error
  const [countdown, setCountdown] = useState(60);
  const [canResend, setCanResend] = useState(false);
  const inputRefs = useRef([]);

  useEffect(() => {
    inputRefs.current[0]?.focus();
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) { clearInterval(timer); setCanResend(true); return 0; }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleChange = (idx, val) => {
    if (!/^\d?$/.test(val)) return;
    const next = [...otp];
    next[idx] = val;
    setOtp(next);
    setStatus('idle');
    if (val && idx < 5) inputRefs.current[idx + 1]?.focus();
  };

  const handleKeyDown = (idx, e) => {
    if (e.key === 'Backspace' && !otp[idx] && idx > 0) {
      inputRefs.current[idx - 1]?.focus();
    }
  };

  const handlePaste = (e) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    const next = [...otp];
    pasted.split('').forEach((ch, i) => { if (i < 6) next[i] = ch; });
    setOtp(next);
    inputRefs.current[Math.min(pasted.length, 5)]?.focus();
  };

  const verify = () => {
    const entered = otp.join('');
    if (entered.length < 6) { setStatus('error'); return; }
    if (entered === MOCK_OTP) {
      setStatus('success');
      setTimeout(onVerified, 800);
    } else {
      setStatus('error');
    }
  };

  const resend = () => {
    setCountdown(60);
    setCanResend(false);
    setStatus('idle');
    setOtp(['', '', '', '', '', '']);
    // TODO: call JDC backend to resend OTP
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) { clearInterval(timer); setCanResend(true); return 0; }
        return prev - 1;
      });
    }, 1000);
  };

  return (
    <div className="otp-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="otp-modal anim-fadeInUp">
        <button className="otp-close" onClick={onClose}>✕</button>

        <div className="otp-icon">✉️</div>
        <h2 className="otp-title">Verify Your Email</h2>
        <p className="otp-sub">
          We sent a 6-digit code to<br />
          <strong>{email}</strong>
        </p>

        {/* Dev hint */}
        <div className="otp-dev-hint">
          <span>🛠 Dev: use <code>{MOCK_OTP}</code></span>
        </div>

        <div className="otp-inputs" onPaste={handlePaste}>
          {otp.map((digit, i) => (
            <input
              key={i}
              ref={el => (inputRefs.current[i] = el)}
              id={`otp-digit-${i}`}
              className={`otp-digit ${status === 'error' ? 'error' : ''} ${status === 'success' ? 'success' : ''}`}
              type="text"
              inputMode="numeric"
              maxLength={1}
              value={digit}
              onChange={e => handleChange(i, e.target.value)}
              onKeyDown={e => handleKeyDown(i, e)}
              autoComplete="off"
            />
          ))}
        </div>

        {status === 'error' && <p className="otp-feedback error">❌ Incorrect OTP. Please try again.</p>}
        {status === 'success' && <p className="otp-feedback success">✅ Verified! Redirecting...</p>}

        <button
          id="otp-verify-btn"
          className="btn btn-primary btn-full mt-16"
          onClick={verify}
          disabled={status === 'success'}
        >
          Verify OTP
        </button>

        <div className="otp-resend">
          {canResend ? (
            <button type="button" className="otp-resend-btn" onClick={resend}>Resend OTP</button>
          ) : (
            <span>Resend in <strong>{countdown}s</strong></span>
          )}
        </div>
      </div>
    </div>
  );
}
