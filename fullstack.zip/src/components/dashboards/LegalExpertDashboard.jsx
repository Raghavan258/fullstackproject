import React, { useState } from 'react';
import './RoleDashboard.css';

const ARTICLES_LIST = [
  { id: 1, title: 'Article 14 — Right to Equality', status: 'Active', commentary: '' },
  { id: 2, title: 'Article 21 — Right to Life & Liberty', status: 'Active', commentary: '' },
  { id: 3, title: 'Article 32 — Right to Constitutional Remedies', status: 'Outdated', commentary: 'This interpretation may need updating post 2021 amendment.' },
  { id: 4, title: 'Article 370 — Special Status (Abrogated)', status: 'Flagged', commentary: 'Requires updated legal commentary following 2019 abrogation.' },
];

const FOCUS_TASKS = [
  { text: 'Summarize the 106th Amendment (Article 15 — Women\'s Reservation)', done: false },
  { text: 'Write landmark case note on Kesavananda Bharati (1973)', done: false },
  { text: 'Review misleading content flagged in Article 370 section', done: false },
  { text: 'Add commentary on Right to Privacy (K.S. Puttaswamy, 2017)', done: false },
];

const STATUS_COLOR = { Active: 'badge-green', Flagged: 'badge-red', Outdated: 'badge-saffron' };

export default function LegalExpertDashboard({ user }) {
  const [articles, setArticles] = useState(ARTICLES_LIST.map(a => ({ ...a, input: '' })));
  const [tasks, setTasks] = useState(FOCUS_TASKS);
  const [activeTab, setActiveTab] = useState('commentary');

  const saveCommentary = (id) => {
    setArticles(p => p.map(a => a.id === id ? { ...a, commentary: a.input, input: '' } : a));
  };

  const flagContent = (id) => {
    setArticles(p => p.map(a => a.id === id ? { ...a, status: 'Flagged' } : a));
  };

  const toggleTask = (i) => setTasks(p => p.map((t, j) => j === i ? { ...t, done: !t.done } : t));
  const doneCount = tasks.filter(t => t.done).length;

  return (
    <div className="role-dashboard">
      <div className="dash-header">
        <div>
          <div className="section-tag">⚖️ Legal Expert</div>
          <h1 className="dash-title heading-display">Expert <span className="saffron-text">Commentary Panel</span></h1>
          <p className="dash-sub">Add legal insights, clarify articles, and review constitutional content.</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid-4 mb-24">
        <div className="stat-card"><div className="stat-value">{articles.filter(a=>a.commentary).length}</div><div className="stat-label">💬 Commentaries Added</div></div>
        <div className="stat-card"><div className="stat-value">{articles.filter(a=>a.status==='Flagged').length}</div><div className="stat-label">🚩 Articles Flagged</div></div>
        <div className="stat-card"><div className="stat-value">{doneCount}/{tasks.length}</div><div className="stat-label">📋 Tasks Done</div></div>
        <div className="stat-card"><div className="stat-value">3</div><div className="stat-label">📜 Cases Noted</div></div>
      </div>

      {/* Tabs */}
      <div className="dash-tabs">
        {['commentary', 'tasks'].map(tab => (
          <button key={tab} className={`dash-tab ${activeTab === tab ? 'active' : ''}`} onClick={() => setActiveTab(tab)}>
            {tab === 'commentary' ? '⚖️ Article Commentary' : "📋 Today's Focus"}
          </button>
        ))}
      </div>

      {activeTab === 'commentary' && (
        <div className="flex flex-col gap-20 mt-16">
          {articles.map(a => (
            <div key={a.id} className="glass-card dash-section-card">
              <div className="section-card-header">
                <div>
                  <div style={{fontWeight:700,fontSize:'1rem',marginBottom:'4px'}}>{a.title}</div>
                  {a.commentary && (
                    <div className="query-answer" style={{marginTop:'4px'}}>💬 {a.commentary}</div>
                  )}
                </div>
                <div style={{display:'flex',gap:'8px',alignItems:'center'}}>
                  <span className={`badge ${STATUS_COLOR[a.status] || 'badge-navy'}`}>{a.status}</span>
                  {a.status !== 'Flagged' && (
                    <button
                      className="btn btn-ghost"
                      style={{fontSize:'0.75rem',padding:'4px 12px',color:'#ff4d6d',borderColor:'rgba(255,77,109,0.3)'}}
                      onClick={() => flagContent(a.id)}
                    >
                      🚩 Flag
                    </button>
                  )}
                </div>
              </div>
              <div style={{display:'flex',gap:'10px',marginTop:'14px'}}>
                <input
                  className="form-input"
                  placeholder="Add legal insight / clarify this article..."
                  value={a.input}
                  onChange={e => setArticles(p => p.map(x => x.id === a.id ? { ...x, input: e.target.value } : x))}
                />
                <button
                  className="btn btn-primary"
                  style={{flexShrink:0,fontSize:'0.82rem',padding:'0 16px'}}
                  onClick={() => saveCommentary(a.id)}
                >
                  Save
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'tasks' && (
        <div className="glass-card dash-section-card mt-16">
          <div className="section-card-header">
            <h3>📋 Today's Focus Tasks</h3>
            <span className="badge badge-saffron">{doneCount}/{tasks.length}</span>
          </div>
          <div className="progress-bar mt-8 mb-16">
            <div className="progress-fill" style={{ width: `${(doneCount / tasks.length) * 100}%` }} />
          </div>
          {tasks.map((t, i) => (
            <div key={i} className={`checklist-item ${t.done ? 'done' : ''}`} onClick={() => toggleTask(i)}>
              <span className="check-box">{t.done ? '✅' : '⬜'}</span>
              <span className="check-text">{t.text}</span>
            </div>
          ))}
          <div className="divider" />
          <div className="grid-2 mt-16">
            <div style={{background:'var(--bg-glass)',borderRadius:'var(--radius-md)',padding:'16px',border:'1px solid var(--border)'}}>
              <div style={{fontWeight:700,marginBottom:'8px',fontSize:'0.9rem'}}>📜 Amendment Summary</div>
              <p style={{fontSize:'0.8rem',color:'var(--text-muted)',lineHeight:1.6}}>106th Amendment (2023) — Women's Reservation Bill. Provides 33% reservation for women in Lok Sabha and State Assemblies.</p>
            </div>
            <div style={{background:'var(--bg-glass)',borderRadius:'var(--radius-md)',padding:'16px',border:'1px solid var(--border)'}}>
              <div style={{fontWeight:700,marginBottom:'8px',fontSize:'0.9rem'}}>🏛️ Landmark Case Note</div>
              <p style={{fontSize:'0.8rem',color:'var(--text-muted)',lineHeight:1.6}}>Kesavananda Bharati vs. State of Kerala (1973) — Established the doctrine of Basic Structure, limiting Parliament's power to amend the Constitution.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
