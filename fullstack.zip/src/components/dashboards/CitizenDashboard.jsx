import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './RoleDashboard.css';

const QUIZZES_DONE = 7;
const TOTAL_QUIZZES = 12;
const BADGES = ['📖 First Read', '🧠 Quiz Ace', '🏛️ Explorer', '⭐ Week Streak'];

const MODULES = [
  { id: 1, title: 'Fundamental Rights Explained', educator: 'Priya Menon', video: 'https://example.com/video1', desc: 'A comprehensive video module on Articles 12–35.' },
  { id: 2, title: 'Constitutional History of India', educator: 'Dr. Rao', video: 'https://example.com/video2', desc: 'From drafting to adoption — the full journey.' },
  { id: 3, title: 'Duties of a Citizen (Article 51A)', educator: 'Adv. Sharma', video: 'https://example.com/video3', desc: 'Understanding your responsibilities as an Indian citizen.' },
];

const DUTIES_LIST = [
  'Read one constitutional article today',
  'Attempt the weekly quiz',
  'Participate in a forum discussion',
  'Explore Constitution Explorer',
  'Submit a query if you have doubts',
];

const QUERIES = [
  { q: 'What is the significance of Article 32?', a: 'Article 32 is the right to constitutional remedies — called the "heart of the Constitution" by Dr. Ambedkar.', answered: true },
  { q: 'Can fundamental rights be suspended?', a: null, answered: false },
];

export default function CitizenDashboard({ user }) {
  const [duties, setDuties] = useState(DUTIES_LIST.map(d => ({ text: d, done: false })));
  const doneCount = duties.filter(d => d.done).length;
  const progress = Math.round((QUIZZES_DONE / TOTAL_QUIZZES) * 100);

  return (
    <div className="role-dashboard">
      <div className="dash-header">
        <div>
          <div className="section-tag">👤 Citizen / Student</div>
          <h1 className="dash-title heading-display">My Learning <span className="saffron-text">Hub</span></h1>
          <p className="dash-sub">Welcome back, {user?.name}! Continue your constitutional journey.</p>
        </div>
        <div className="dash-header-actions">
          <Link to="/quizzes" className="btn btn-primary">🧠 Attempt Quiz</Link>
        </div>
      </div>

      {/* Progress overview */}
      <div className="grid-4 mb-24">
        <div className="stat-card">
          <div className="stat-value" style={{color:'var(--saffron-light)'}}>{QUIZZES_DONE}/{TOTAL_QUIZZES}</div>
          <div className="stat-label">📝 Quizzes Completed</div>
        </div>
        <div className="stat-card">
          <div className="stat-value" style={{color:'#4cbc3b'}}>{BADGES.length}</div>
          <div className="stat-label">🏅 Badges Earned</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{doneCount}/{duties.length}</div>
          <div className="stat-label">✅ Daily Duties Done</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">3</div>
          <div className="stat-label">💬 Forum Posts</div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="glass-card dash-section-card mb-24">
        <div className="section-card-header">
          <h3>📊 Overall Progress</h3>
          <span className="badge badge-saffron">{progress}% complete</span>
        </div>
        <div className="progress-bar mt-8">
          <div className="progress-fill" style={{ width: `${progress}%` }} />
        </div>
        <div className="badges-row mt-16">
          {BADGES.map(b => (
            <span key={b} className="badge badge-navy" style={{padding:'6px 14px',fontSize:'0.8rem'}}>{b}</span>
          ))}
        </div>
      </div>

      <div className="grid-2 mb-24">
        {/* Quick Access */}
        <div className="glass-card dash-section-card">
          <div className="section-card-header"><h3>🚀 Quick Access</h3></div>
          <div className="quick-links">
            {[
              { icon: '🎥', label: 'Video Library', path: '/video-library' },
              { icon: '📓', label: 'Study Notes', path: '/study-notes' },
              { icon: '🧠', label: 'Quizzes', path: '/quizzes' },
              { icon: '🗺️', label: 'Constitution Explorer', path: '/constitution-explorer' },
              { icon: '💬', label: 'Community Forums', path: '/forums' },
              { icon: '📄', label: 'Articles', path: '/articles' },
            ].map(item => (
              <Link key={item.path} to={item.path} className="quick-link-btn">
                <span className="ql-icon">{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            ))}
          </div>
        </div>

        {/* My Duties */}
        <div className="glass-card dash-section-card">
          <div className="section-card-header">
            <h3>📋 My Daily Duties</h3>
            <span className="badge badge-green">{doneCount}/{duties.length}</span>
          </div>
          <div className="divider" />
          {duties.map((d, i) => (
            <div
              key={i}
              className={`checklist-item ${d.done ? 'done' : ''}`}
              onClick={() => setDuties(prev => prev.map((x, j) => j === i ? { ...x, done: !x.done } : x))}
            >
              <span className="check-box">{d.done ? '✅' : '⬜'}</span>
              <span className="check-text">{d.text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Educator Modules */}
      <div className="glass-card dash-section-card mb-24">
        <div className="section-card-header">
          <h3>🏫 Educator Modules for You</h3>
          <span className="badge badge-navy">Published</span>
        </div>
        <div className="grid-3 mt-16">
          {MODULES.map(m => (
            <div key={m.id} className="module-card">
              <div className="module-icon">📹</div>
              <div className="module-title">{m.title}</div>
              <div className="module-educator">by {m.educator}</div>
              <p className="module-desc">{m.desc}</p>
              <a href={m.video} target="_blank" rel="noopener noreferrer" className="btn btn-outline" style={{fontSize:'0.8rem',padding:'7px 16px',marginTop:'10px'}}>
                ▶ Watch
              </a>
            </div>
          ))}
        </div>
      </div>

      {/* My Queries */}
      <div className="glass-card dash-section-card">
        <div className="section-card-header">
          <h3>❓ My Queries & Answers</h3>
          <button className="btn btn-primary" style={{fontSize:'0.8rem',padding:'8px 16px'}}>+ Submit Query</button>
        </div>
        {QUERIES.map((q, i) => (
          <div key={i} className="query-item">
            <div className="query-question">Q: {q.q}</div>
            {q.answered
              ? <div className="query-answer">💬 {q.a}</div>
              : <div className="query-pending">⏳ Awaiting response from educator/legal expert</div>
            }
          </div>
        ))}
      </div>
    </div>
  );
}
