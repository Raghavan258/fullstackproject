import React, { useState } from 'react';
import './RoleDashboard.css';

const MODULES = [
  { id: 1, title: 'Preamble Deep Dive', status: 'Published', video: 'https://example.com/v1', desc: 'Explaining the preamble word by word.' },
  { id: 2, title: 'Fundamental Rights', status: 'In Review', video: '', desc: 'Articles 12–35 with case studies.' },
  { id: 3, title: 'Constitutional Amendments', status: 'Draft', video: '', desc: 'A chronological guide to all amendments.' },
];

const QUERIES = [
  { id: 1, from: 'Arjun Sharma', q: 'What is the significance of Article 32?', answered: false },
  { id: 2, from: 'Meera K.', q: 'How does Article 21 protect privacy?', answered: false },
  { id: 3, from: 'Rahul V.', q: 'What is Right to Education under Article 21A?', answered: true, a: 'Article 21A mandates free and compulsory education for all children between 6–14 years.' },
];

const STATUS_COLOR = { Published: 'badge-green', 'In Review': 'badge-saffron', Draft: 'badge-navy' };

export default function EducatorDashboard({ user }) {
  const [modules, setModules] = useState(MODULES.map(m => ({ ...m, videoInput: m.video })));
  const [queries, setQueries] = useState(QUERIES.map(q => ({ ...q, reply: '' })));
  const [activeTab, setActiveTab] = useState('modules');

  const updateVideo = (id, val) => setModules(p => p.map(m => m.id === id ? { ...m, videoInput: val } : m));
  const saveVideo = (id) => setModules(p => p.map(m => m.id === id ? { ...m, video: m.videoInput } : m));
  const setReply = (id, val) => setQueries(p => p.map(q => q.id === id ? { ...q, reply: val } : q));
  const submitReply = (id) => setQueries(p => p.map(q => q.id === id && q.reply.trim() ? { ...q, answered: true, a: q.reply } : q));

  return (
    <div className="role-dashboard">
      <div className="dash-header">
        <div>
          <div className="section-tag">🏫 Educator</div>
          <h1 className="dash-title heading-display">Teaching <span className="saffron-text">Toolkit</span></h1>
          <p className="dash-sub">Create, manage modules, and answer citizen queries.</p>
        </div>
        <div className="dash-header-actions">
          <button className="btn btn-primary">+ New Module</button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid-4 mb-24">
        <div className="stat-card"><div className="stat-value">{modules.filter(m=>m.status==='Published').length}</div><div className="stat-label">✅ Published</div></div>
        <div className="stat-card"><div className="stat-value">{modules.filter(m=>m.status==='In Review').length}</div><div className="stat-label">🔍 In Review</div></div>
        <div className="stat-card"><div className="stat-value">{modules.filter(m=>m.status==='Draft').length}</div><div className="stat-label">📝 Drafts</div></div>
        <div className="stat-card"><div className="stat-value">{queries.filter(q=>!q.answered).length}</div><div className="stat-label">❓ Pending Queries</div></div>
      </div>

      {/* Teaching Toolkit Info */}
      <div className="glass-card dash-section-card mb-24">
        <div className="section-card-header"><h3>📚 Teaching Toolkit</h3></div>
        <div className="grid-3">
          {[
            ['🎯', 'Focus Areas', 'Cover Fundamental Rights, D.P.S.P., and Amendments in your modules'],
            ['📹', 'Video Lectures', 'Add YouTube/Drive video URLs to your published modules'],
            ['💡', 'Best Practices', 'Keep module descriptions concise. Aim for 15–20 min video segments'],
          ].map(([icon, title, desc]) => (
            <div key={title} style={{display:'flex',gap:'12px',alignItems:'flex-start'}}>
              <span style={{fontSize:'1.6rem'}}>{icon}</span>
              <div>
                <div style={{fontWeight:700,marginBottom:'4px',fontSize:'0.9rem'}}>{title}</div>
                <div style={{fontSize:'0.8rem',color:'var(--text-muted)',lineHeight:1.6}}>{desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="dash-tabs">
        {['modules', 'queries'].map(tab => (
          <button key={tab} className={`dash-tab ${activeTab === tab ? 'active' : ''}`} onClick={() => setActiveTab(tab)}>
            {tab === 'modules' ? '🧩 Module Pipeline' : '❓ Assigned Queries'}
          </button>
        ))}
      </div>

      {activeTab === 'modules' && (
        <div className="flex flex-col gap-16">
          {modules.map(m => (
            <div key={m.id} className="glass-card dash-section-card">
              <div className="section-card-header">
                <div>
                  <div style={{fontWeight:700,fontSize:'1rem'}}>{m.title}</div>
                  <div style={{fontSize:'0.8rem',color:'var(--text-muted)',marginTop:'4px'}}>{m.desc}</div>
                </div>
                <span className={`badge ${STATUS_COLOR[m.status]}`}>{m.status}</span>
              </div>
              {m.status !== 'Published' && (
                <div style={{display:'flex',gap:'10px',marginTop:'14px'}}>
                  <input
                    className="form-input"
                    placeholder="Add/edit video lecture URL..."
                    value={m.videoInput}
                    onChange={e => updateVideo(m.id, e.target.value)}
                  />
                  <button className="btn btn-primary" style={{flexShrink:0,fontSize:'0.82rem',padding:'0 16px'}} onClick={() => saveVideo(m.id)}>
                    Save URL
                  </button>
                </div>
              )}
              {m.video && <div style={{marginTop:'8px',fontSize:'0.78rem',color:'var(--saffron-light)'}}>▶ {m.video}</div>}
            </div>
          ))}
        </div>
      )}

      {activeTab === 'queries' && (
        <div className="flex flex-col gap-16">
          {queries.map(q => (
            <div key={q.id} className="glass-card dash-section-card">
              <div className="section-card-header">
                <div>
                  <div style={{fontSize:'0.78rem',color:'var(--text-muted)',marginBottom:'4px'}}>From: {q.from}</div>
                  <div className="query-question">Q: {q.q}</div>
                </div>
                <span className={`badge ${q.answered ? 'badge-green' : 'badge-saffron'}`}>{q.answered ? 'Answered' : 'Pending'}</span>
              </div>
              {q.answered
                ? <div className="query-answer">✅ {q.a}</div>
                : (
                  <div style={{marginTop:'12px',display:'flex',gap:'10px'}}>
                    <textarea
                      className="form-input"
                      rows={2}
                      placeholder="Type your reply..."
                      value={q.reply}
                      onChange={e => setReply(q.id, e.target.value)}
                      style={{resize:'vertical'}}
                    />
                    <button className="btn btn-primary" style={{flexShrink:0,alignSelf:'flex-end',fontSize:'0.82rem',padding:'10px 16px'}} onClick={() => submitReply(q.id)}>
                      Reply
                    </button>
                  </div>
                )
              }
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
