import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './RoleDashboard.css';

const ARTICLES = [
  { id: 1, title: 'Article 14 — Right to Equality', status: 'Published', views: 4200 },
  { id: 2, title: 'Article 19 — Freedom of Speech', status: 'Published', views: 3800 },
  { id: 3, title: 'Article 21 — Right to Life', status: 'Draft', views: 0 },
];

const MODULES = [
  { id: 1, title: 'Preamble Deep Dive', educator: 'Priya Menon', status: 'In Review' },
  { id: 2, title: 'Fundamental Rights', educator: 'Adv. Sharma', status: 'Published' },
  { id: 3, title: 'Constitutional Amendments', educator: 'Dr. Rao', status: 'Draft' },
];

const USERS = {
  students: 12847,
  educators: 284,
  legalExperts: 96,
};

const VIOLATIONS = [
  { user: 'anon_user_42', type: 'Spam', date: '2026-04-07' },
  { user: 'test.user@mail.com', type: 'Inappropriate Comment', date: '2026-04-06' },
];

const DUTIES = [
  'Review pending article submissions',
  'Approve 3 educator modules in queue',
  'Check reported violations',
  'Update weekly legal expert assignments',
  'Publish monthly quiz set',
];

export default function AdminDashboard() {
  const [duties, setDuties] = useState(DUTIES.map(d => ({ text: d, done: false })));
  const [activeTab, setActiveTab] = useState('overview');

  const toggleDuty = (i) => setDuties(prev => prev.map((d, idx) => idx === i ? { ...d, done: !d.done } : d));

  const doneCount = duties.filter(d => d.done).length;

  return (
    <div className="role-dashboard">
      {/* Header */}
      <div className="dash-header">
        <div>
          <div className="section-tag">🛡️ Admin Panel</div>
          <h1 className="dash-title heading-display">Admin <span className="saffron-text">Dashboard</span></h1>
          <p className="dash-sub">Manage content, users, and monitor platform health.</p>
        </div>
        <div className="dash-header-actions">
          <Link to="/articles" className="btn btn-outline">📝 All Articles</Link>
        </div>
      </div>

      {/* Stats */}
      <div className="grid-4 mb-24">
        <div className="stat-card"><div className="stat-value">{USERS.students.toLocaleString()}</div><div className="stat-label">👤 Students</div></div>
        <div className="stat-card"><div className="stat-value">{USERS.educators}</div><div className="stat-label">🏫 Educators</div></div>
        <div className="stat-card"><div className="stat-value">{USERS.legalExperts}</div><div className="stat-label">⚖️ Legal Experts</div></div>
        <div className="stat-card"><div className="stat-value">{ARTICLES.length}</div><div className="stat-label">📄 Articles</div></div>
      </div>

      {/* Tabs */}
      <div className="dash-tabs">
        {['overview','articles','modules','users','violations'].map(tab => (
          <button
            key={tab}
            className={`dash-tab ${activeTab === tab ? 'active' : ''}`}
            onClick={() => setActiveTab(tab)}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <div className="grid-2">
          {/* Admin Duties */}
          <div className="glass-card dash-section-card">
            <div className="section-card-header">
              <h3>📋 Admin Duties Checklist</h3>
              <span className="badge badge-saffron">{doneCount}/{duties.length} done</span>
            </div>
            <div className="progress-bar mt-8 mb-16">
              <div className="progress-fill" style={{ width: `${(doneCount / duties.length) * 100}%` }} />
            </div>
            {duties.map((d, i) => (
              <div key={i} className={`checklist-item ${d.done ? 'done' : ''}`} onClick={() => toggleDuty(i)}>
                <span className="check-box">{d.done ? '✅' : '⬜'}</span>
                <span className="check-text">{d.text}</span>
              </div>
            ))}
          </div>

          {/* Violations */}
          <div className="glass-card dash-section-card">
            <div className="section-card-header">
              <h3>⚠️ User Violations</h3>
              <span className="badge badge-red">{VIOLATIONS.length} pending</span>
            </div>
            {VIOLATIONS.map((v, i) => (
              <div className="violation-item" key={i}>
                <div>
                  <div className="violation-user">{v.user}</div>
                  <div className="violation-type">{v.type}</div>
                </div>
                <div className="violation-date">{v.date}</div>
              </div>
            ))}
            <button className="btn btn-ghost w-full mt-16" style={{fontSize:'0.82rem'}}>View All Violations</button>
          </div>
        </div>
      )}

      {activeTab === 'articles' && (
        <div className="glass-card dash-section-card">
          <div className="section-card-header"><h3>📄 Manage Articles</h3><button className="btn btn-primary" style={{fontSize:'0.8rem',padding:'8px 16px'}}>+ New Article</button></div>
          <table className="dash-table">
            <thead><tr><th>Title</th><th>Status</th><th>Views</th><th>Action</th></tr></thead>
            <tbody>
              {ARTICLES.map(a => (
                <tr key={a.id}>
                  <td>{a.title}</td>
                  <td><span className={`badge ${a.status === 'Published' ? 'badge-green' : 'badge-navy'}`}>{a.status}</span></td>
                  <td>{a.views.toLocaleString()}</td>
                  <td><button className="btn btn-ghost" style={{fontSize:'0.75rem',padding:'4px 12px'}}>Edit</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'modules' && (
        <div className="glass-card dash-section-card">
          <div className="section-card-header"><h3>🧩 Manage Modules</h3></div>
          <table className="dash-table">
            <thead><tr><th>Module</th><th>Educator</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
              {MODULES.map(m => (
                <tr key={m.id}>
                  <td>{m.title}</td>
                  <td>{m.educator}</td>
                  <td><span className={`badge ${m.status === 'Published' ? 'badge-green' : m.status === 'In Review' ? 'badge-saffron' : 'badge-navy'}`}>{m.status}</span></td>
                  <td><button className="btn btn-ghost" style={{fontSize:'0.75rem',padding:'4px 12px'}}>Review</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'users' && (
        <div className="grid-3">
          {[['👤','Students',USERS.students,'citizen'],['🏫','Educators',USERS.educators,'educator'],['⚖️','Legal Experts',USERS.legalExperts,'legal_expert']].map(([icon, label, count, role]) => (
            <div className="glass-card dash-section-card" key={label}>
              <div className="section-card-header">
                <h3>{icon} {label}</h3>
                <span className="badge badge-navy">{count}</span>
              </div>
              <p style={{fontSize:'0.82rem',color:'var(--text-muted)'}}>View and manage all {label.toLowerCase()} registered on the platform.</p>
              <button className="btn btn-outline w-full mt-16" style={{fontSize:'0.82rem'}}>View {label}</button>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'violations' && (
        <div className="glass-card dash-section-card">
          <div className="section-card-header"><h3>⚠️ All Violations</h3></div>
          {VIOLATIONS.map((v, i) => (
            <div className="violation-item" key={i}>
              <div>
                <div className="violation-user">{v.user}</div>
                <div className="violation-type">{v.type} — <span style={{color:'var(--text-muted)'}}>{v.date}</span></div>
              </div>
              <div style={{display:'flex',gap:'8px'}}>
                <button className="btn btn-ghost" style={{fontSize:'0.75rem',padding:'4px 12px'}}>Dismiss</button>
                <button className="btn btn-outline" style={{fontSize:'0.75rem',padding:'4px 12px',borderColor:'#ff4d6d',color:'#ff4d6d'}}>Ban</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
